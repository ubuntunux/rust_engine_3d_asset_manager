import bpy
import bpy_extras
import os
import json
import math
import shutil
import sys
import traceback

from collections import OrderedDict
from enum import Enum
from pathlib import Path
from mathutils import Vector
from .asset_descriptor import AssetTypeCatalogNames, AssetExts, AssetMetadata, AssetExportPriority
from . import utilities

__logger__ = None

def get_bound(collection):    
    m = sys.float_info.min
    M = sys.float_info.max
    pos_min = Vector((M,M,M))
    pos_max = Vector((m,m,m))
    meshes = [obj for obj in collection.objects if obj.type == 'MESH']
    for mesh in meshes:
        for v in mesh.bound_box:
            pos = mesh.matrix_world @ Vector(v)
            pos_min = Vector([min(z) for z in zip(pos, pos_min)])
            pos_max = Vector([max(z) for z in zip(pos, pos_max)])
    return (pos_min, pos_max)

def collect_object(asset, object_list: list):
    object_list.extend(list(asset.objects))
    for grand_child in asset.children:
        collect_object(grand_child, object_list)

class ResourceTypeInfo:
    def __init__(self, resource_dirname, resource_ext, external_ext):
        self.resource_dirname = resource_dirname
        self.resource_ext = resource_ext
        self.external_ext = external_ext


class ResourceType(Enum):
    MATERIAL_INSTANCE = ResourceTypeInfo('material_instances', '.matinst', None)
    MODEL = ResourceTypeInfo('models', '.model', None)
    MESH = ResourceTypeInfo('meshes', '.mesh', '.gltf')


class AssetInfo:
    asset_import_manager = None

    def __init__(self, asset):
        catalog_simple_name = self.asset_import_manager.get_asset_catalog_name_by_id(asset.asset_data.catalog_id)
        tokens = catalog_simple_name.split('/')

        self.asset_name = asset.name
        self.catalog_simple_name = catalog_simple_name
        self.asset_library_path = '/'.join(tokens)
        self.asset_library_name = tokens[0]
        self.asset_type_name = tokens[1]
        self.asset_relative_path = '/'.join(tokens[1:])
        self.asset_namepath = os.path.join('/'.join(tokens[2:]), self.asset_name)
        self.asset_fullpath = os.path.join(self.asset_relative_path, self.asset_name)

    def __str__(self):
        return str(self.__dict__)

    def get_asset_filepath(self, resource_path, ext):
        return os.path.join(resource_path, self.asset_relative_path, self.asset_name) + ext


class AssetExportManager:
    def __init__(self, logger, library_name, asset_import_manager):
        global __logger__
        __logger__ = logger

        AssetInfo.asset_import_manager = asset_import_manager

        self.asset_import_manager = asset_import_manager
        self.library_name = library_name
        self.asset_library = bpy.context.preferences.filepaths.asset_libraries.get(library_name)
        self.external_path = os.path.normpath(self.asset_library.path)
        self.resource_path = os.path.split(self.external_path)[0]

    def convert_axis(self, axis):
        return [axis[0], axis[2], axis[1]]

    def convert_asset_location(self, asset):
        return self.convert_axis(list(asset.location))

    def convert_asset_rotation(self, asset, rx=0.0, ry=0.0, rz=0.0):
        rotation_euler = list(asset.rotation_euler)
        rotation_euler[0] = math.radians(rx) - rotation_euler[0]
        rotation_euler[1] = math.radians(ry) - rotation_euler[1]
        rotation_euler[2] = math.radians(rz) - rotation_euler[2]
        return self.convert_axis(rotation_euler)

    def convert_asset_scale(self, asset):
        return self.convert_axis(list(asset.scale))

    def convert_asset_dimensions(self, asset):
        return self.convert_axis(list(asset.dimensions))

    def convert_light_color(self, asset):
        return [asset.data.energy * x for x in list(asset.data.color)]

    def get_object_center(self, obj):
        center = Vector((0,0,0))
        for v in obj.bound_box:
            center += obj.matrix_world @ Vector(v)
        return center / 8

    def copy_file(self, title, src_filepath, dst_filepath):
        __logger__.info(f'{title}: {dst_filepath}')
        try:
            dst_dirpath = os.path.split(dst_filepath)[0]
            if not os.path.exists(dst_dirpath):
                os.makedirs(dst_dirpath)
            shutil.copy(src_filepath, dst_filepath)
        except:
            __logger__.error(traceback.format_exc())
            raise

    def write_to_file(self, title, data, export_filepath):
        __logger__.info(f'{title}: {export_filepath}')
        export_path = os.path.split(export_filepath)[0]
        if not os.path.exists(export_path):
            os.makedirs(export_path)

        with open(export_filepath, 'w') as f:
            f.write(json.dumps(data, sort_keys=True, indent=4))

    def export_animation_layers(self, asset, asset_info):
        bone_blend_map = OrderedDict()

        for child in asset.children:
            for child_object in [x for x in child.objects if 'ARMATURE' == x.type]:
                for constraint in [x for x in child_object.constraints if 'ARMATURE' == x.type]:
                    for target in constraint.targets:
                        bone_blend_map[target.subtarget] = target.weight

        animation_layers = OrderedDict({
            "_bone_blend_map": bone_blend_map
        })

        # export animation_layers
        export_filepath = asset_info.get_asset_filepath(self.resource_path, '.layer')
        self.write_to_file('export animation_layers', animation_layers, export_filepath)

    def export_material_instance(self, asset_info, mesh_collection):
        texture_dirpath = os.path.join(self.resource_path, 'textures')
        material_instance_name_paths = []
        materials_list = [child.data.materials for child in mesh_collection.objects if 'MESH' == child.type]
        material_instance_slots_list = [child.material_slots for child in mesh_collection.objects if 'MESH' == child.type]
        for list_index in range(len(materials_list)):
            materials = materials_list[list_index]
            material_instance_slots = material_instance_slots_list[list_index]
            for material_index in range(len(materials)):
                material = materials[material_index]
                if material is None or material.asset_data is None:
                    continue

                material_instance = material_instance_slots[material_index].material
                if material_instance is None or material_instance.asset_data is None:
                    continue

                material_asset_info = AssetInfo(material)
                material_instance_asset_info = AssetInfo(material_instance)
                material_instance_name_paths.append(material_instance_asset_info.asset_namepath)

                # export material instance
                material_parameters = OrderedDict()
                material_instance_info = OrderedDict({
                    'material_name': material_asset_info.asset_namepath,
                    'material_parameters': material_parameters
                })

                for node in material_instance.node_tree.nodes:
                    if node.label:
                        if 'TEX_IMAGE' == node.type:
                            # gather texture parameter
                            image_filepath = node.image.filepath.replace('\\', '/')
                            if image_filepath:
                                tokens = image_filepath.split('/')
                                textures_index = tokens.index('textures')
                                image_relative_filepath = os.path.join(*tokens[textures_index:])
                                image_filepath = os.path.abspath(os.path.join(self.resource_path, image_relative_filepath))
                                image_namepath = os.path.splitext(os.path.relpath(image_filepath, texture_dirpath))[0]
                                material_parameters[node.label] = image_namepath

                                # export texture
                                EXPORT_TEXTURES = False
                                if EXPORT_TEXTURES:
                                    image_external_filepath = os.path.abspath(os.path.join(self.external_path, ))
                                    if os.path.exists(image_external_filepath):
                                        src_modified_time = os.path.getmtime(image_external_filepath)
                                        dst_modified_time = os.path.getmtime(image_filepath) if os.path.exists(image_filepath) else 0
                                        if dst_modified_time < src_modifed_time:
                                            self.copy_file('export texture', image_external_filepath, image_filepath)
                        elif 'RGB' == node.type:
                            material_parameters[node.label] = list(node.outputs[0].default_value)
                        elif 'VALUE' == node.type:
                            material_parameters[node.label] = node.outputs[0].default_value

                # export material instance
                export_filepath = material_instance_asset_info.get_asset_filepath(self.resource_path, ".matinst")
                self.write_to_file('export material_instance', material_instance_info, export_filepath)
        return material_instance_name_paths

    def export_selected_meshes(self, asset, asset_info):
        # export material instance
        self.export_material_instance(asset_info, asset)

        export_filepath = asset_info.get_asset_filepath(self.resource_path, '.gltf')

        try:
            export_dirpath = os.path.split(export_filepath)[0]
            if not os.path.exists(export_dirpath):
                os.makedirs(export_dirpath)

            bpy.ops.export_scene.gltf(
                filepath=export_filepath,
                export_format='GLTF_SEPARATE',
                use_selection=True,
                export_apply=True,
                export_yup=True,
                export_texcoords=True,
                export_normals=True,
                export_tangents=True,
                export_materials='NONE',
                export_skins=True,
                export_animations=True,
                export_force_sampling=True,
                export_bake_animation=True,
                export_optimize_animation_size=False,
                export_optimize_animation_keep_anim_armature=True,
                export_anim_single_armature=False,
                export_reset_pose_bones=True
            )
            __logger__.info(f'export_selected_meshes {asset_info.asset_namepath}: {export_filepath}')
        except:
            __logger__.error(traceback.format_exc())
            raise

    def export_models(self, asset, asset_info):
        __logger__.info(f'export_models: {asset_info.asset_namepath}')

        if 0 < len(asset.children):
            mesh_collection = asset.children[0]

            # mesh
            mesh_data = mesh_collection.override_library.reference
            if not mesh_data.asset_data:
                __logger__.error(f'failed to export_models: {asset_info.asset_namepath}')
                return

            mesh_asset_info = AssetInfo(mesh_data)
            mesh_path = mesh_asset_info.asset_namepath
            is_render_camera = True
            is_render_shadow = True

            # material instance
            material_instances = self.export_material_instance(asset_info, mesh_collection)

            # local transform object
            position = [0.0, 0.0, 0.0]
            rotation = [0.0, 0.0, 0.0]
            scale = [1.0, 1.0, 1.0]

            # default bound
            (default_pos_min, default_pos_max) = get_bound(mesh_collection)

            # bounding box
            bounding_box = OrderedDict({
                "_min": self.convert_axis(default_pos_min),
                "_max": self.convert_axis(default_pos_max)
            })

            # collision
            collision = OrderedDict({
                "_collision_type": "NONE",
                "_location": [0, 0, 0],
                "_extents": [0.5, 0.5, 0.5]
            })

            # sockets
            sockets = OrderedDict()

            # extra objects
            for obj in asset.objects:
                if obj.name.startswith('COLLISION'):
                    pos_min = obj.location - obj.dimensions * 0.5
                    pos_max = obj.location + obj.dimensions * 0.5
                    location = (pos_max + pos_min) * 0.5
                    collision['_collision_type'] = obj.display_bounds_type if obj.display_bounds_type in ['CYLINDER', 'SPHERE'] else 'BOX'
                    collision['_location'] = self.convert_axis(location)
                    collision['_extents'] = self.convert_axis(obj.dimensions * 0.5)
                elif obj.name.startswith('BOUND_BOX'):
                    pos_min = obj.location - obj.dimensions * 0.5
                    pos_max = obj.location + obj.dimensions * 0.5
                    bounding_box['_min'] = self.convert_axis(pos_min)
                    bounding_box['_max'] = self.convert_axis(pos_max)
                elif obj.name.startswith('SOCKET_'):
                    if obj.parent and obj.parent_type == 'BONE':
                        sockets[obj.name] = OrderedDict({
                            '_parent_bone': obj.parent_bone,
                            '_position': self.convert_asset_location(obj),
                            '_rotation': self.convert_asset_rotation(obj),
                            '_scale': self.convert_asset_scale(obj)
                        })

            # model transform
            for (model_obj, mesh_obj) in zip(mesh_collection.objects, mesh_data.objects):
                if mesh_obj.parent is None:
                    mesh_location = self.convert_asset_location(mesh_obj)
                    mesh_rotation = self.convert_asset_rotation(mesh_obj)
                    mesh_scale = self.convert_asset_scale(mesh_obj)
                    model_location = self.convert_asset_location(model_obj)
                    model_rotation = self.convert_asset_rotation(model_obj)
                    model_scale = self.convert_asset_scale(model_obj)
                    position = [model_location[0] - mesh_location[0], model_location[1] - mesh_location[1], model_location[2] - mesh_location[2]]
                    rotation = [model_rotation[0] - mesh_rotation[0], model_rotation[1] - mesh_rotation[1], model_rotation[2] - mesh_rotation[2]]
                    scale = [model_scale[0] / mesh_scale[0], model_scale[1] / mesh_scale[1], model_scale[2] / mesh_scale[2]]
                    is_render_camera = model_obj.visible_camera
                    is_render_shadow = model_obj.visible_shadow
                    break

            # export model
            model_info = OrderedDict({
                "_mesh": mesh_path,
                "_position": position,
                "_rotation": rotation,
                "_scale": scale,
                "_is_render_camera": is_render_camera,
                "_is_render_shadow": is_render_shadow,
                "_material_instances": material_instances,
                "_collision": collision,
                "_sockets": sockets
            })
            export_model_filepath = asset_info.get_asset_filepath(self.resource_path, '.model')
            self.write_to_file('export model', model_info, export_model_filepath)

    def get_game_scene_data(self, asset):
        # collect objects
        object_list = []
        collect_object(asset, object_list)
        game_scene_data = OrderedDict()

        # export objects
        for child in object_list:
            __logger__.info(f'get_game_scene_data object: {(child.name, type(child), child.type)}')
            if 'EMPTY' == child.type:
                if 'COLLECTION' == child.instance_type:
                    child_asset_info = AssetInfo(child.instance_collection)
                    __logger__.info(f'    object: {(child.name, type(child), child.type, child_asset_info.__dict__, )}')
                    if 'game_scene' == child_asset_info.asset_type_name:
                        game_scene_data = OrderedDict({
                            "_game_scene_data_name": child_asset_info.asset_namepath,
                            "_position": self.convert_asset_location(child),
                            "_rotation": self.convert_asset_rotation(child),
                            "_scale": self.convert_asset_scale(child)
                        })
                    else:
                        __logger__.error(f'not implemented asset type {(child.name, child_asset_info.asset_type_name)}')
                else:
                    __logger__.error(f'not implemented asset type {(child.name, child_asset_info.asset_type_name)}')
            else:
                __logger__.error(f'not implemented object type {(child.name, child.type)}')
        return game_scene_data

    def get_scene_data(self, asset):
        cameras = OrderedDict()
        directional_lights = OrderedDict()
        point_lights = OrderedDict()
        effects = OrderedDict()
        static_objects = OrderedDict()
        skeletal_objects = OrderedDict()

        scene_data = OrderedDict({
            "_cameras": cameras,
            "_directional_lights": directional_lights,
            "_point_lights": point_lights,
            "_effects": effects,
            "_static_objects": static_objects,
            "_skeletal_objects": skeletal_objects
        })

        # collect objects
        object_list = []
        collect_object(asset, object_list)

        # export objects
        for child in object_list:
            __logger__.debug(f'object: {(child.name, type(child))}')
            if 'LIGHT' == child.type:
                light_color = self.convert_light_color(child)
                light_rotation = self.convert_asset_rotation(child, rx=90.0)

                if 'SUN' == child.data.type:
                    directional_lights[child.name] = OrderedDict({
                        "_rotation": light_rotation,
                        "_light_data": OrderedDict({
                            "_light_direction": light_rotation,
                            "_light_color": light_color,
                        })
                    })
                elif 'POINT' == child.data.type:
                    point_lights[child.name] = OrderedDict({
                        "_light_position": self.convert_asset_location(child),
                        "_radius": child.data.shadow_soft_size,
                        "_light_color": light_color
                    })
            elif 'CAMERA' == child.type:
                cameras[child.name] = OrderedDict({
                    # 'fov': math.degrees(child.data.angle),
                    'position': self.convert_asset_location(child),
                    'rotation': self.convert_asset_rotation(child, rx=90.0)
                })
            elif 'EMPTY' == child.type:
                if 'COLLECTION' == child.instance_type:
                    child_asset_info = AssetInfo(child.instance_collection)
                    if 'models' == child_asset_info.asset_type_name:
                        scene_object_type = "Default"
                        if child.users_collection:
                            if child.users_collection[0].name == '_collision':
                                scene_object_type = "Collision"
                            elif child.users_collection[0].name == '_no_collision':
                                scene_object_type = "NoCollision"
                            elif child.users_collection[0].name == '_terrain':
                                scene_object_type = "Terrain"
                        static_objects[child.name] = OrderedDict({
                            "_scene_object_type": scene_object_type,
                            "_model_data_name": child_asset_info.asset_namepath,
                            "_position": self.convert_asset_location(child),
                            "_rotation": self.convert_asset_rotation(child),
                            "_scale": self.convert_asset_scale(child)
                        })
                    else:
                        __logger__.error(f'not implemented asset type {(child.name, child_asset_info.asset_type_name)}')
                else:
                    __logger__.error(f'not implemented asset type {(child.name, child_asset_info.asset_type_name)}')
            else:
                __logger__.error(f'not implemented object type {(child.name, child.type)}')
        return scene_data

    def export_scenes(self, asset, asset_info):
        __logger__.info(f'export_scenes: {asset_info.asset_namepath}')
        scene_data = self.get_scene_data(asset)
        export_filepath = asset_info.get_asset_filepath(self.resource_path, ".scene")
        self.write_to_file('export scene', scene_data, export_filepath)

    def parse_item_effects_property(self, key, property_value):
        if isinstance(property_value, str):
            raw = property_value.strip()
            if not raw:
                return []
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError as e:
                __logger__.error(f'invalid JSON for {key}: {raw!r} ({e})')
                return []
            if isinstance(parsed, list):
                return parsed
            if isinstance(parsed, dict):
                return [{k: v} for k, v in parsed.items()]
            __logger__.error(f'unexpected JSON type for {key}: {type(parsed)}')
            return []
        if hasattr(property_value, 'to_dict'):
            return [{k: v} for k, v in property_value.to_dict().items()]
        if hasattr(property_value, 'to_list'):
            return list(property_value.to_list())
        __logger__.error(f'get_game_data_character not implemented type: {key, type(property_value)}')
        return []

    def asset_property_to_game_data(self, property_asset, game_data):
        for key in property_asset.keys():
            if key not in property_asset.bl_rna.properties:
                property_value = property_asset[key]
                property_type = type(property_value)
                if key == '_item_effects':
                    effects = self.parse_item_effects_property(key, property_value)
                    if effects:
                        game_data[key] = effects
                elif key == '_weapon_type' and isinstance(property_value, str):
                    weapon_type = property_value.strip() or 'None'
                    game_data[key] = weapon_type
                elif property_type in [bool, int, float, str]:
                     game_data[key] = property_value
                elif property_type is bpy.types.Collection:
                    if property_value and property_value.asset_data:
                        property_value_asset_info = AssetInfo(property_value)
                        game_data[key] = property_value_asset_info.asset_namepath
                else:
                    __logger__.error(f'get_game_data_character not implemented type: {key, property_type}')

        for child_property_asset in property_asset.children:
             child_game_data = OrderedDict()
             self.asset_property_to_game_data(child_property_asset, child_game_data)
             game_data["_" + child_property_asset.name] = child_game_data

    def get_custom_properties(self, asset, asset_info, property_asset_name):
        object_list = []
        collect_object(asset, object_list)

        game_data = OrderedDict()
        for property_asset in object_list:
            if property_asset.name == property_asset_name:
                self.asset_property_to_game_data(property_asset, game_data)
        return game_data

    def export_game_data(self, asset, asset_info):
        __logger__.info(f'export_game_data: {asset_info.asset_namepath}, library_name: {self.library_name}, external_path: {self.external_path}, resource_path: {self.resource_path}')

        tokens = asset_info.asset_library_path.split('/')
        if 'game_data' == asset_info.asset_type_name and 2 < len(tokens):
            game_data = OrderedDict()
            game_data_ext = '.data'
            game_data_type = tokens[2]
            if 'characters' == game_data_type:
                game_data = self.get_custom_properties(asset, asset_info, 'character_data')
                for child_object in asset.objects:
                    if 'WEAPON' == child_object.name and child_object.parent:
                        child_asset = child_object.instance_collection
                        weapon_asset_info = AssetInfo(child_asset)
                        game_data["_weapon_create_info"] = OrderedDict({
                            "_weapon_socket_name": child_object.parent.name,
                            "_weapon_data_name": weapon_asset_info.asset_namepath,
                            "_position": self.convert_asset_location(child_object),
                            "_rotation": self.convert_asset_rotation(child_object),
                            "_scale": self.convert_asset_scale(child_object)
                        })
            elif 'items' == game_data_type:
                game_data = self.get_custom_properties(asset, asset_info, 'item_data')
            elif 'props' == game_data_type:
                game_data = self.get_custom_properties(asset, asset_info, 'prop_data')
            elif 'weapons' == game_data_type:
                game_data = self.get_custom_properties(asset, asset_info, 'weapon_data')
            elif 'game_scenes' == game_data_type:
                game_data = self.get_game_data_scenes(asset, asset_info)
            elif 'scenario' == game_data_type:
                game_data = self.get_game_data_scenario(asset, asset_info)
            else:
                __logger__.error(f'not implemented game data: {asset_info.asset_fullpath}')
                
            if game_data:
                export_filepath = asset_info.get_asset_filepath(self.resource_path, game_data_ext)
                self.write_to_file('export game_data', game_data, export_filepath)
                return
        __logger__.error(f'error export_game_data: {asset_info.asset_fullpath}')

    # export game asset
    def get_game_asset_data(self, asset_container, child_asset, asset_data_name, scene_object_type = None):
        object_list = []
        collect_object(child_asset, object_list)
        for child_object in object_list:
            if child_object.instance_collection is None or child_object.instance_collection.asset_data is None:
                __logger__.info(f'none child_object: {child_object.name, child_object.instance_collection}')
            child_object_info = AssetInfo(child_object.instance_collection)
            asset_container[child_object.name] = OrderedDict({
                asset_data_name: child_object_info.asset_namepath,
                "_position": self.convert_asset_location(child_object),
                "_rotation": self.convert_asset_rotation(child_object),
                "_scale": self.convert_asset_scale(child_object)
            })

            if scene_object_type:
                asset_container[child_object.name]["_scene_object_type"] = scene_object_type

            instance_parameters = {}
            self.asset_property_to_game_data(child_object, instance_parameters)
            if instance_parameters:
                asset_container[child_object.name]["_instance_parameters"] = instance_parameters

    # export game scene
    def get_game_data_scenes(self, asset, asset_info):
        characters = OrderedDict()
        items = OrderedDict()
        player = OrderedDict()
        props = OrderedDict()
        game_data = OrderedDict({
            "_characters": characters,
            "_items": items,
            "_player": player,
            "_props": props,
            "_scene": {}
        })

        for child_asset in asset.children:
            if '_characters' == child_asset.name:
                self.get_game_asset_data(characters, child_asset, "_character_data_name")
            elif '_items' == child_asset.name:
                self.get_game_asset_data(items, child_asset, "_item_data_name")
            elif '_props' == child_asset.name:
                self.get_game_asset_data(props, child_asset, "_prop_data_name")
            elif '_player' == child_asset.name:
                self.get_game_asset_data(player, child_asset, "_character_data_name")
            elif '_scene' == child_asset.name:
                game_data['_scene'] = self.get_scene_data(child_asset)
            else:
                __logger__.error(f'not implemented object type {child_asset.name}')
        return game_data

    # export game scenario
    def get_game_data_scenario(self, asset, asset_info):
        characters = OrderedDict()
        items = OrderedDict()
        player = OrderedDict()
        props = OrderedDict()
        game_scenes = OrderedDict()
        game_data = OrderedDict({
            "_characters": characters,
            "_items": items,
            "_player": player,
            "_props": props,
            "_game_scenes": game_scenes,
            "_scene": {}
        })

        for child_asset in asset.children:
            if '_characters' == child_asset.name:
                self.get_game_asset_data(characters, child_asset, "_character_data_name")
            elif '_items' == child_asset.name:
                self.get_game_asset_data(items, child_asset, "_item_data_name")
            elif '_props' == child_asset.name:
                self.get_game_asset_data(props, child_asset, "_prop_data_name")
            elif '_player' == child_asset.name:
                self.get_game_asset_data(player, child_asset, "_character_data_name")
            elif '_game_scenes' == child_asset.name:
                self.get_game_asset_data(game_scenes, child_asset, "_game_scene_data_name")
            elif '_scene' == child_asset.name:
                game_data['_scene'] = self.get_scene_data(child_asset)
            else:
                __logger__.error(f'not implemented object type {child_asset.name}')
        return game_data

    # export asset
    def export_asset(self, asset):
        asset_info = AssetInfo(asset)
        __logger__.info(f'export_asset: {asset_info.asset_fullpath}')

        if 'animation_layers' == asset_info.asset_type_name:
            self.export_animation_layers(asset, asset_info)
        elif 'meshes' == asset_info.asset_type_name:
            self.export_selected_meshes(asset, asset_info)
        elif 'models' == asset_info.asset_type_name:
            self.export_models(asset, asset_info)
        elif 'scenes' == asset_info.asset_type_name:
            self.export_scenes(asset, asset_info)
        elif 'game_data' == asset_info.asset_type_name:
            self.export_game_data(asset, asset_info)
        else:
            __logger__.error(f'error export_asset: {asset_info.asset_type_name}')

    def export_selected_assets(self):
        bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
        #bpy.ops.object.select_all(action='SELECT')
        selected_objects = bpy.context.selected_objects
        __logger__.info(f">>> export_assets: {selected_objects}")
        for asset in selected_objects:
            bpy.ops.object.select_all(action='DESELECT')
            asset.select_set(True)
            asset.location = [0, 0, 0]
            if 'EMPTY' == asset.type and 'COLLECTION' == asset.instance_type:
                self.export_asset(asset.instance_collection)
            else:
                __logger__.error(f'error export_selected_objects: {asset.type}')
        __logger__.info(f'>>> End: export_assets')

    def load_blend_file(self, blend_file):
        with bpy.data.libraries.load(blend_file, assets_only=True, link=True) as (data_from, data_to):
            data_to.materials = data_from.materials
            data_to.meshes = data_from.meshes
            data_to.collections = data_from.collections
            data_to.actions = data_from.actions
            data_to.armatures = data_from.armatures
            data_to.objects = data_from.objects
            return data_to

    def export_library_asset(self, asset, asset_data):
        bpy.context.scene.collection.objects.link(asset)
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = asset
        asset.select_set(True)
        asset.location = [0, 0, 0]

        # export asset data
        self.export_asset(asset_data)

    def export_blend(self, blend_file):
        __logger__.info(f"export_blend: {blend_file}")

        if os.path.exists(blend_file):
            utilities.clear_scene(read_homefile=False)
            data = self.load_blend_file(blend_file)
            if data:
                for (i, collection) in enumerate(data.collections):
                    # create a collection
                    empty = bpy.data.objects.new(collection.name, None)
                    empty.instance_type = 'COLLECTION'
                    empty.instance_collection = collection
                    # export
                    self.export_library_asset(empty, collection)

    def export_resources(self):
        __logger__.info(f'>>> export_resource: {self.asset_library.path}')

        # build asset metadata of exporter
        exporter_asset_metadata = {}
        catalog_names = AssetTypeCatalogNames.get_catalog_names()
        all_asset_exts = AssetExts.get_asset_exts()
        for asset_type, catalog_name in catalog_names.items():
            asset_dir = Path(self.resource_path, catalog_name)
            for dirpath, dirnames, filenames in os.walk(asset_dir):
                for filename in filenames:
                    filepath = Path(dirpath, filename)
                    ext = filepath.suffix.lower()
                    asset_path = filepath.relative_to(asset_dir).with_suffix('').as_posix()
                    if ext in all_asset_exts[asset_type]:
                        asset_metadata = AssetMetadata(
                            asset_type=asset_type,
                            asset_path=asset_path,
                            filepath=filepath,
                            mtime=utilities.get_mtime(filepath)
                        )
                        if asset_type not in exporter_asset_metadata:
                            exporter_asset_metadata[asset_type] = {}
                        exporter_asset_metadata[asset_type][asset_path] = asset_metadata

        # load asset metadata of importer
        asset_metadata_in_files = {}
        importer_asset_metadata = self.asset_import_manager.get_asset_metadata_list()
        for asset_type, asset_metadata_by_type in importer_asset_metadata.items():
            for asset_path, asset_metadata in asset_metadata_by_type.items():
                filepath = asset_metadata.get_filepath()
                if not filepath.exists():
                    continue

                if filepath not in asset_metadata_in_files:
                    asset_metadata_in_files[filepath] = []
                asset_metadata_in_files[filepath].append(asset_metadata)

        # export assets
        export_filepaths = []
        for filepath, asset_metadata_list in asset_metadata_in_files.items():
            source_file_mtime = utilities.get_mtime(filepath)
            for source_asset_metadata in asset_metadata_list:
                asset_type = source_asset_metadata.get_asset_type()
                asset_path = source_asset_metadata.get_asset_path()
                export_assets = True
                if asset_type in exporter_asset_metadata and asset_path in exporter_asset_metadata[asset_type]:
                    target_asset_metadata = exporter_asset_metadata[asset_type][asset_path]
                    if target_asset_metadata.get_filepath().exists() and source_file_mtime <= target_asset_metadata.get_mtime():
                        export_assets = False

                if export_assets and filepath.suffix.lower() == '.blend':
                    export_filepaths.append((AssetExportPriority.get_asset_type_export_priority(asset_type), filepath.as_posix()))
                    break
                else:
                    __logger__.debug(f'>>> skip export filepath: {filepath}, assets: {[metadata.get_asset_path() for metadata in asset_metadata_list]}')
                    pass

        export_filepaths.sort()
        for (priority, export_filepath) in export_filepaths:
            self.export_blend(export_filepath)

        # remove asset_metadata
        # for asset_type, asset_metadata_list in exporter_asset_metadata.items():
        #     for asset_path, asset_metadata in asset_metadata_list.items():
        #         if asset_type not in importer_asset_metadata or asset_path not in importer_asset_metadata[asset_type]:
        #             __logger__.info(f'remove asset: {asset_metadata.get_filepath()}')
        #             os.remove(asset_metadata.get_filepath())

        # clear scene
        utilities.clear_scene(read_homefile=False)

    def run_export_resources(self):
        if bpy.context.selected_objects:
            self.export_selected_assets()
        else:
            self.export_resources()

        #self.export_blend('/home/ubuntunux/WorkSpace/StoneAge/resources/externals/models/environments/cactus.blend')
        #self.export_blend('/home/ubuntunux/WorkSpace/StoneAge/resources/externals/meshes/environments/cliff_grass.blend')
        #self.export_blend('/home/ubuntunux/WorkSpace/StoneAge/resources/externals/meshes/characters/jack/jack.blend')
        #self.export_blend('/home/ubuntunux/WorkSpace/StoneAge/resources/externals/models/characters/jack.blend')